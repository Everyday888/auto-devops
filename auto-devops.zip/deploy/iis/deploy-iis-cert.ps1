param(
    [Parameter(Mandatory = $true)]
    [string]$PfxPath,

    [Parameter(Mandatory = $true)]
    [string]$PfxPassword,

    [Parameter(Mandatory = $false)]
    [string]$CertDomain = "",

    [Parameter(Mandatory = $false)]
    [string]$CertExpireDate = ""
)

$ErrorActionPreference = 'Stop'

if (!(Test-Path -Path $PfxPath)) {
    throw "PFX 文件不存在: $PfxPath"
}

$securePwd = ConvertTo-SecureString $PfxPassword -AsPlainText -Force
$newCert = Import-PfxCertificate -FilePath $PfxPath -CertStoreLocation 'Cert:\LocalMachine\My' -Password $securePwd -Exportable
if (-not $newCert) {
    throw "Import-PfxCertificate 导入失败"
}

$thumbprint = $newCert.Thumbprint

Import-Module WebAdministration
$bindings = Get-WebBinding -Protocol https
if (-not $bindings) {
    throw '未找到 IIS HTTPS 绑定，请先在 IIS 中配置 https 站点绑定'
}

$targetDomainNoWildcard = ($CertDomain | ForEach-Object { $_.Trim() }).TrimStart('*').TrimStart('.')
$targetBindings = @()

if ($targetDomainNoWildcard) {
    foreach ($binding in $bindings) {
        $hostHeader = $binding.HostHeader
        if (-not $hostHeader) {
            continue
        }
        if ($hostHeader -eq $targetDomainNoWildcard -or $hostHeader -like ('*.' + $targetDomainNoWildcard)) {
            $targetBindings += $binding
        }
    }
}

if (-not $targetBindings -or $targetBindings.Count -eq 0) {
    $targetBindings = $bindings
}

$updated = @()
foreach ($binding in $targetBindings) {
    $binding.AddSslCertificate($thumbprint, 'my')
    $updated += $binding.bindingInformation
}

# Collect thumbprints still used by IIS HTTPS bindings to avoid deleting in-use certificates.
$inUseThumbprints = @()
foreach ($binding in (Get-WebBinding -Protocol https)) {
    try {
        $certObj = Get-Item ("IIS:\SslBindings\" + $binding.BindingInformation.Replace(':', '!')) -ErrorAction Stop
        if ($certObj -and $certObj.Thumbprint) {
            $inUseThumbprints += $certObj.Thumbprint.ToUpper()
        }
    } catch {
        # Ignore bindings that cannot resolve thumbprint via IIS provider.
    }
}
$inUseThumbprints = $inUseThumbprints | Select-Object -Unique

$deletedOldCertCount = 0
$targetDomainNoWildcard = ($targetDomainNoWildcard | ForEach-Object { $_.Trim().ToLower() })
$now = Get-Date

$candidateCerts = Get-ChildItem Cert:\LocalMachine\My
foreach ($cert in $candidateCerts) {
    if (-not $cert -or -not $cert.Thumbprint) {
        continue
    }

    $tp = $cert.Thumbprint.ToUpper()
    if ($tp -eq $thumbprint.ToUpper()) {
        continue
    }
    if ($inUseThumbprints -contains $tp) {
        continue
    }

    $dnsNames = @()
    try {
        foreach ($ext in $cert.Extensions) {
            if ($ext.Oid.FriendlyName -eq 'Subject Alternative Name') {
                $formatted = $ext.Format($false)
                $parts = $formatted -split ','
                foreach ($part in $parts) {
                    $piece = $part.Trim()
                    if ($piece -like 'DNS Name=*') {
                        $dnsNames += $piece.Substring(9).Trim().ToLower()
                    }
                }
            }
        }
    } catch {}

    $subjectMatch = $false
    if ($targetDomainNoWildcard) {
        if ($dnsNames -contains $targetDomainNoWildcard) {
            $subjectMatch = $true
        } elseif (($dnsNames | Where-Object { $_ -like ('*.' + $targetDomainNoWildcard) }).Count -gt 0) {
            $subjectMatch = $true
        } elseif ($cert.Subject -match [regex]::Escape($targetDomainNoWildcard)) {
            $subjectMatch = $true
        }
    }

    $expired = ($cert.NotAfter -lt $now)
    if ($expired -or $subjectMatch) {
        try {
            Remove-Item -Path ("Cert:\LocalMachine\My\" + $cert.Thumbprint) -Force -ErrorAction Stop
            $deletedOldCertCount++
        } catch {
            # Ignore certificate deletion failures to avoid breaking deployment.
        }
    }
}

$iisResetOutput = (& iisreset /noforce 2>&1 | Out-String)

Write-Output ('UPDATED_BINDINGS=' + ($updated -join '; '))
Write-Output ('UPDATED_COUNT=' + $updated.Count)
Write-Output ('CERT_THUMBPRINT=' + $thumbprint)
Write-Output ('CERT_NOTAFTER=' + $newCert.NotAfter.ToString('yyyy-MM-dd HH:mm:ss'))
Write-Output ('CERT_EXPIRE_DATE=' + ($(if ($CertExpireDate) { $CertExpireDate } else { $newCert.NotAfter.ToString('yyyy-MM-dd') })))
Write-Output ('DELETED_OLD_CERT_COUNT=' + $deletedOldCertCount)
Write-Output ('IISRESET_OUTPUT=' + $iisResetOutput)
