import json
import csv
import io
import os
import re
import socket
import ssl
import tempfile
import base64
import shutil
import subprocess
from datetime import datetime, timezone
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session, Response
from config import *
from cert_api import (
    list_api_certs, apply_and_verify_bg, do_dns_verify,
    download_cert, delete_cert, get_local_certs, get_local_pfx_certs, get_cert_detail, get_local_cert_details,
    delete_local_cert
)
from aws_real import (
    deploy_lb, get_load_balancers, get_cloudfronts, upload_iam_cert, deploy_cf,
    list_iam_certs_with_bindings, delete_iam_cert
)

app = Flask(__name__)
app.secret_key = APP_SECRET_KEY

ENV_FILE_PATH = os.path.join(os.path.dirname(__file__), ".env")
OPS_LOG_PATH = os.path.join(os.path.dirname(__file__), "logs", "operations.log")


def _render(page, **kwargs):
    """统一渲染，注入所有页面共用数据"""
    defaults = {
        "api_certs": [], "cfs": [], "lbs": [], "linux": [], "iis": [],
        "dns_records": [], "local_cert_details": [], "iam_certs": [], "iam_active_certs": [],
        "cert_check_domains": [], "cert_checks": [], "operation_logs": []
    }
    defaults.update(kwargs)
    return render_template(
        "index.html",
        page=page,
        current_user=session.get("user"),
        domains=DOMAINS,
        local_certs=get_local_certs(),
        iis_certs=get_local_pfx_certs(),
        **defaults
    )


def _wants_json():
    return request.headers.get("X-Requested-With") == "XMLHttpRequest"


def _json_or_redirect(ok, msg, redirect_endpoint, **payload):
    if request.method == "POST" and request.endpoint not in {"login_post"}:
        _log_operation(request.endpoint or request.path, ok, msg, payload)

    if _wants_json():
        data = {"ok": ok, "message": msg}
        data.update(payload)
        return jsonify(data), (200 if ok else 400)
    flash(msg, "success" if ok else "danger")
    return redirect(request.referrer or url_for(redirect_endpoint))


def _safe_dump(data):
    try:
        return json.dumps(data, ensure_ascii=False)
    except Exception:
        return str(data)


def _log_operation(action, ok, message, payload=None):
    try:
        os.makedirs(os.path.dirname(OPS_LOG_PATH), exist_ok=True)
        entry = {
            "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "user": session.get("user", ""),
            "ip": request.headers.get("X-Forwarded-For", request.remote_addr or ""),
            "action": action,
            "ok": bool(ok),
            "message": str(message or ""),
            "payload": _safe_dump(payload or {})
        }
        with open(OPS_LOG_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
    except Exception:
        pass


def _parse_log_time(value):
    if not value:
        return None
    try:
        return datetime.strptime(value, "%Y-%m-%d %H:%M:%S")
    except Exception:
        return None


def _read_operation_logs(limit=300, user_filter="", start_time="", end_time=""):
    if not os.path.isfile(OPS_LOG_PATH):
        return []

    try:
        with open(OPS_LOG_PATH, "r", encoding="utf-8") as f:
            lines = [line.strip() for line in f if line.strip()]
    except Exception:
        return []

    user_filter = (user_filter or "").strip().lower()
    start_dt = _parse_log_time(start_time)
    end_dt = _parse_log_time(end_time)
    result = []

    for line in reversed(lines[-limit:]):
        try:
            entry = json.loads(line)
            if user_filter and str(entry.get("user", "")).strip().lower() != user_filter:
                continue

            item_dt = _parse_log_time(entry.get("time", ""))
            if start_dt and item_dt and item_dt < start_dt:
                continue
            if end_dt and item_dt and item_dt > end_dt:
                continue

            result.append(entry)
        except Exception:
            continue
    return result


def _build_ops_logs_csv(logs):
    stream = io.StringIO()
    writer = csv.writer(stream)
    writer.writerow(["time", "user", "ip", "action", "ok", "message", "payload"])
    for item in logs:
        writer.writerow([
            item.get("time", ""),
            item.get("user", ""),
            item.get("ip", ""),
            item.get("action", ""),
            "success" if item.get("ok") else "failed",
            item.get("message", ""),
            item.get("payload", ""),
        ])
    return stream.getvalue()


def _write_env_value(key, value):
    line = f"{key}={value}"
    lines = []

    if os.path.isfile(ENV_FILE_PATH):
        with open(ENV_FILE_PATH, "r", encoding="utf-8") as env_file:
            lines = env_file.read().splitlines()

    replaced = False
    new_lines = []
    for existing in lines:
        if existing.startswith(f"{key}="):
            new_lines.append(line)
            replaced = True
        else:
            new_lines.append(existing)

    if not replaced:
        if new_lines and new_lines[-1] != "":
            new_lines.append("")
        new_lines.append(line)

    with open(ENV_FILE_PATH, "w", encoding="utf-8") as env_file:
        env_file.write("\n".join(new_lines).rstrip() + "\n")

    os.environ[key] = value


def _save_server_list(env_key, target_list, servers):
    payload = json.dumps(servers, ensure_ascii=False, separators=(",", ":"))
    _write_env_value(env_key, payload)
    target_list[:] = servers


def _save_cert_check_domains(domains):
    unique_domains = list(dict.fromkeys([d.strip().lower() for d in domains if d and d.strip()]))
    _write_env_value("CERT_CHECK_DOMAINS_CSV", ",".join(unique_domains))
    CERT_CHECK_DOMAINS[:] = unique_domains


def _mark_linux_server_deploy_state(host, cert_domain, ok, msg):
    host = (host or "").strip()
    if not host:
        return

    now_text = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    servers = [dict(item) for item in LINUX_SERVERS]
    changed = False
    for item in servers:
        if item.get("host") != host:
            continue

        item["last_deploy_at"] = now_text
        item["last_deploy_ok"] = bool(ok)
        item["last_deploy_message"] = str(msg or "")
        if ok:
            item["deployed_cert"] = str(cert_domain or "")
            item["deployed_at"] = now_text
        changed = True
        break

    if changed:
        _save_server_list("LINUX_SERVERS_JSON", LINUX_SERVERS, servers)


def _mark_iis_server_deploy_state(host, cert_domain, ok, msg):
    host = (host or "").strip()
    if not host:
        return

    now_text = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    servers = [dict(item) for item in IIS_SERVERS]
    changed = False
    for item in servers:
        if item.get("host") != host:
            continue

        item["last_deploy_at"] = now_text
        item["last_deploy_ok"] = bool(ok)
        item["last_deploy_message"] = str(msg or "")
        if ok:
            item["deployed_cert"] = str(cert_domain or "")
            item["deployed_at"] = now_text
        changed = True
        break

    if changed:
        _save_server_list("IIS_SERVERS_JSON", IIS_SERVERS, servers)


def _extract_server_deploy_state(server):
    return {
        "host": str(server.get("host", "") or ""),
        "deployed_cert": str(server.get("deployed_cert", "") or ""),
        "deployed_at": str(server.get("deployed_at", "") or ""),
        "last_deploy_at": str(server.get("last_deploy_at", "") or ""),
        "last_deploy_ok": bool(server.get("last_deploy_ok", False)),
        "last_deploy_message": str(server.get("last_deploy_message", "") or ""),
    }


def _get_server_deploy_state(servers, host):
    host = (host or "").strip()
    if not host:
        return None

    for server in servers:
        if server.get("host") == host:
            return _extract_server_deploy_state(server)
    return None


def _normalize_linux_server(form):
    deploy_type = form.get("deploy_type", "nginx").strip().lower() or "nginx"
    if deploy_type not in {"nginx", "socket_server", "gitlab"}:
        deploy_type = "nginx"
    return {
        "name": form.get("name", "").strip(),
        "host": form.get("host", "").strip(),
        "user": form.get("user", "").strip(),
        "ssl_path": form.get("ssl_path", "").strip() or "/etc/nginx/ssl/",
        "deploy_type": deploy_type,
        "key": form.get("key", "").strip(),
        "password": form.get("password", "").strip()
    }


def _normalize_iis_server(form):
    protocol = form.get("protocol", "http").strip().lower() or "http"
    port_raw = form.get("port", "").strip()
    default_port = 5986 if protocol == "https" else 5985
    try:
        port = int(port_raw or default_port)
    except ValueError:
        port = None

    return {
        "name": form.get("name", "").strip(),
        "host": form.get("host", "").strip(),
        "protocol": protocol,
        "port": port,
        "version": form.get("version", "new").strip().lower() or "new",
        "user": form.get("user", "").strip(),
        "password": form.get("password", "").strip(),
        "deploy_script": form.get("deploy_script", "").strip()
    }


def _validate_linux_server(server):
    if not server["name"]:
        return False, "Linux 服务器名称不能为空"
    if not server["host"]:
        return False, "Linux 服务器主机不能为空"
    if server.get("deploy_type") not in {"nginx", "socket_server", "gitlab"}:
        return False, "Linux 部署类型必须是 nginx / socket_server / gitlab"
    if not _is_local_host(server.get("host")) and not server["user"]:
        return False, "Linux 服务器用户名不能为空"
    return True, ""


def _is_local_host(host):
    value = str(host or "").strip().lower()
    return value in {"127.0.0.1", "localhost", "::1"}


def _pick_first_existing(cert_dir, names):
    for name in names:
        p = os.path.join(cert_dir, name)
        if os.path.isfile(p):
            return p
    return ""


def _detect_private_key_type(private_key_path):
    try:
        with open(private_key_path, "r", encoding="utf-8", errors="ignore") as f:
            head = f.read(256)
    except Exception:
        return "rsa"

    text = str(head or "").upper()
    if "BEGIN EC PRIVATE KEY" in text:
        return "ec"
    if "BEGIN ENCRYPTED PRIVATE KEY" in text:
        return "pkey"
    if "BEGIN PRIVATE KEY" in text:
        return "pkey"
    return "rsa"


def _run_local_shell(command, work_dir=""):
    proc = subprocess.run(
        command,
        shell=True,
        cwd=work_dir or None,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True
    )
    output = (proc.stdout or "").strip()
    return proc.returncode == 0, output


def _run_ssh_shell(ssh_client, command):
    stdin, stdout, stderr = ssh_client.exec_command(command)
    exit_code = stdout.channel.recv_exit_status()
    out = (stdout.read() or b"").decode("utf-8", errors="ignore")
    err = (stderr.read() or b"").decode("utf-8", errors="ignore")
    text = (out + "\n" + err).strip()
    return exit_code == 0, text


def _sh_quote(value):
    return "'" + str(value or "").replace("'", "'\"'\"'") + "'"


def _build_socket_server_commands(private_key_type, ssl_path=""):
    openssl_tool = "rsa"
    if private_key_type == "ec":
        openssl_tool = "ec"
    elif private_key_type == "pkey":
        openssl_tool = "pkey"

    commands = [
        "cp -f fullchain.crt wildcard_infrontsmart_com.crt",
        f"openssl {openssl_tool} -in private.pem -out wildcard_infrontsmart_com.key",
    ]
    if ssl_path:
        commands.extend([
            f"sudo -n cp -f wildcard_infrontsmart_com.crt {ssl_path}",
            f"sudo -n cp -f wildcard_infrontsmart_com.key {ssl_path}",
        ])
    commands.extend([
        "chmod 777 wildcard_infrontsmart_com.*",
        "sudo systemctl restart *eChat*.service"
    ])
    return commands


def _build_gitlab_commands(private_key_remote, private_key_type, fullchain_remote, ssl_path):
    openssl_tool = "rsa"
    if private_key_type == "ec":
        openssl_tool = "ec"
    elif private_key_type == "pkey":
        openssl_tool = "pkey"

    return [
        f"sudo -n cp -f {fullchain_remote} {ssl_path}/certificate.crt",
        f"sudo -n openssl {openssl_tool} -in {private_key_remote} -out {ssl_path}/certificate.key",
        f"sudo -n chown -R root:root {ssl_path}/certificate.*",
        "sudo -n gitlab-ctl reconfigure",
        "sudo -n gitlab-ctl restart nginx"
    ]


def _validate_iis_server(server):
    if not server["name"]:
        return False, "Windows 服务器名称不能为空"
    if not server["host"]:
        return False, "Windows 服务器主机不能为空"
    if server["port"] is None:
        return False, "Windows 服务器端口格式不正确"
    if server.get("protocol") not in {"http", "https"}:
        return False, "Windows 服务器协议必须是 http 或 https"
    if server.get("version") not in {"old", "new"}:
        return False, "Windows 服务器版本必须是 old 或 new"
    return True, ""


def _create_winrm_session(server):
    import winrm

    host = server.get("host")
    protocol = str(server.get("protocol", "http") or "http").strip().lower()
    port = int(server.get("port", 5986 if protocol == "https" else 5985))
    endpoint = f"{protocol}://{host}:{port}/wsman"

    session_kwargs = {
        "auth": (server.get("user", "Administrator"), server.get("password", "")),
        "transport": "ntlm",
        "operation_timeout_sec": 30,
        "read_timeout_sec": 60,
    }
    if protocol == "https":
        # Many Windows servers use self-signed WinRM certs.
        session_kwargs["server_cert_validation"] = "ignore"

    session = winrm.Session(endpoint, **session_kwargs)
    return session, protocol, port


def _upsert_server(target_list, original_host, new_server):
    original_host = (original_host or "").strip()
    new_host = new_server.get("host", "")
    servers = [dict(item) for item in target_list]

    for item in servers:
        if item.get("host") == new_host and item.get("host") != original_host:
            return False, None, f"服务器主机已存在：{new_host}"

    updated = False
    for index, item in enumerate(servers):
        if item.get("host") == original_host:
            servers[index] = new_server
            updated = True
            break

    if not updated:
        servers.append(new_server)

    servers.sort(key=lambda item: (item.get("name", ""), item.get("host", "")))
    return True, servers, ("服务器已更新" if updated else "服务器已添加")


def _delete_server(target_list, host):
    host = (host or "").strip()
    servers = [dict(item) for item in target_list]
    filtered = [item for item in servers if item.get("host") != host]
    if len(filtered) == len(servers):
        return False, None, f"未找到服务器：{host}"
    filtered.sort(key=lambda item: (item.get("name", ""), item.get("host", "")))
    return True, filtered, "服务器已删除"


def _extract_cert_dn_value(cert, section, key_name):
    for item in cert.get(section, []):
        for pair in item:
            if len(pair) == 2 and pair[0] == key_name:
                return pair[1]
    return ""


def _parse_ssl_time(value):
    if not value:
        return None
    try:
        dt = datetime.strptime(value, "%b %d %H:%M:%S %Y %Z")
        return dt.replace(tzinfo=timezone.utc)
    except Exception:
        return None


def _decode_peer_cert_from_der(der_bytes):
    """把服务端返回的 DER 证书转成 dict 结构，兼容 getpeercert() 的字段访问方式。"""
    if not der_bytes:
        return {}

    pem_text = ssl.DER_cert_to_PEM_cert(der_bytes)
    tmp_path = None
    try:
        with tempfile.NamedTemporaryFile("w", delete=False, suffix=".pem", encoding="utf-8") as tmp:
            tmp.write(pem_text)
            tmp_path = tmp.name
        return ssl._ssl._test_decode_cert(tmp_path)
    except Exception:
        return {}
    finally:
        if tmp_path and os.path.isfile(tmp_path):
            try:
                os.remove(tmp_path)
            except Exception:
                pass


def _check_domain_cert(domain, port=443, timeout=8):
    result = {
        "domain": domain,
        "ok": False,
        "subject_cn": "",
        "issuer_cn": "",
        "not_before": "",
        "not_after": "",
        "days_left": None,
        "san": [],
        "serial_number": "",
        "message": ""
    }

    try:
        context = ssl._create_unverified_context()
        with socket.create_connection((domain, port), timeout=timeout) as sock:
            with context.wrap_socket(sock, server_hostname=domain) as tls_sock:
                cert_der = tls_sock.getpeercert(binary_form=True)

        cert = _decode_peer_cert_from_der(cert_der)

        if not cert:
            result["message"] = "未获取到证书"
            return result

        not_before_raw = cert.get("notBefore", "")
        not_after_raw = cert.get("notAfter", "")
        not_before_dt = _parse_ssl_time(not_before_raw)
        not_after_dt = _parse_ssl_time(not_after_raw)

        result["subject_cn"] = _extract_cert_dn_value(cert, "subject", "commonName")
        result["issuer_cn"] = _extract_cert_dn_value(cert, "issuer", "commonName")
        result["not_before"] = not_before_dt.astimezone().strftime("%Y-%m-%d %H:%M:%S") if not_before_dt else not_before_raw
        result["not_after"] = not_after_dt.astimezone().strftime("%Y-%m-%d %H:%M:%S") if not_after_dt else not_after_raw
        result["serial_number"] = cert.get("serialNumber", "")
        result["san"] = [name for typ, name in cert.get("subjectAltName", []) if typ == "DNS"]

        if not_after_dt:
            delta_days = (not_after_dt - datetime.now(timezone.utc)).days
            result["days_left"] = delta_days

        result["ok"] = True
        result["message"] = "证书获取成功"
        return result
    except Exception as e:
        result["message"] = str(e)
        return result


def _check_tcp_connectivity(host, port, timeout=5):
    try:
        with socket.create_connection((host, int(port)), timeout=timeout):
            return True, ""
    except socket.timeout:
        return False, f"连接超时（{timeout}s）"
    except Exception as e:
        return False, str(e)


def _format_winrm_error(host, port, err_text):
    text = str(err_text or "").strip()
    lowered = text.lower()

    if "timed out" in lowered or "connecttimeout" in lowered:
        return (
            f"WinRM 连接超时：{host}:{port}。"
            "请检查目标机器是否可达、WinRM 服务是否开启、端口是否放通（5985/5986）以及安全组/防火墙策略。"
        )

    if "401" in lowered or "unauthorized" in lowered:
        return (
            f"WinRM 认证失败：{host}:{port}。"
            "请检查用户名/密码、目标主机本地策略、以及是否允许当前认证方式。"
        )

    if "name or service not known" in lowered or "nodename" in lowered:
        return f"WinRM 主机名解析失败：{host}:{port}。请检查主机地址是否正确。"

    return f"WinRM 连接失败：{text}"


def _clean_powershell_output(text):
    if not text:
        return ""

    cleaned = str(text)
    cleaned = cleaned.replace("_x000D__x000A_", "\n")
    cleaned = cleaned.replace("_x000D_", "\n")
    cleaned = cleaned.replace("_x000A_", "\n")
    cleaned = re.sub(r"^#<\s*CLIXML", "", cleaned, flags=re.IGNORECASE).strip()
    cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)
    return cleaned.strip()


def _get_cert_expire_date(cert_domain):
    """根据本地域名，从 API 证书列表中找到对应到期时间（YYYY-MM-DD）。"""
    target = (cert_domain or "").strip().lstrip("*.").lower()
    if not target:
        return ""

    try:
        for cert in list_api_certs():
            domains_raw = str(cert.get("domains", ""))
            domains = [d.strip().lstrip("*.").lower() for d in domains_raw.split(",") if d.strip()]
            if target not in domains:
                continue

            expire = str(cert.get("time_end") or cert.get("expire_date") or "").strip()
            if not expire:
                return ""
            return expire.split()[0]
    except Exception:
        return ""

    return ""


def _get_active_iam_certs():
    try:
        certs = list_iam_certs_with_bindings()
    except Exception:
        return []
    return [cert for cert in certs if not cert.get("is_expired")]


def _find_active_iam_cert(cert_name):
    cert_name = (cert_name or "").strip()
    if not cert_name:
        return None
    for cert in _get_active_iam_certs():
        if cert.get("name") == cert_name:
            return cert
    return None


def _pick_suggested_iam_cert_name(current_cert_name, iam_active_certs):
    current_cert_name = (current_cert_name or "").strip()
    if not iam_active_certs:
        return ""

    for cert in iam_active_certs:
        if cert.get("name") != current_cert_name:
            return cert.get("name", "")

    return iam_active_certs[0].get("name", "")


@app.before_request
def require_login():
    allowed = {"login", "login_post", "static"}
    if request.endpoint in allowed:
        return None
    if session.get("user"):
        return None
    if request.headers.get("X-Requested-With") == "XMLHttpRequest":
        return jsonify({"ok": False, "message": "登录已失效，请重新登录"}), 401
    return redirect(url_for("login"))


@app.route("/login")
def login():
    if session.get("user"):
        return redirect(url_for("index"))
    return render_template("login.html")


@app.route("/login", methods=["POST"])
def login_post():
    username = request.form.get("username", "").strip()
    password = request.form.get("password", "")
    if username == LOGIN_USERNAME and password == LOGIN_PASSWORD:
        session["user"] = username
        _log_operation("login", True, "登录成功", {"username": username})
        flash("登录成功", "success")
        return redirect(url_for("index"))
    _log_operation("login", False, "账号或密码错误", {"username": username})
    flash("账号或密码错误", "danger")
    return redirect(url_for("login"))


@app.route("/logout", methods=["POST"])
def logout():
    user = session.get("user", "")
    session.clear()
    _log_operation("logout", True, "退出登录", {"username": user})
    flash("已退出登录", "success")
    return redirect(url_for("login"))


# ── 首页 ──────────────────────────────────────────────────────────────────────
@app.route("/")
def index():
    return _render("home")


# ── 证书申请 ──────────────────────────────────────────────────────────────────
@app.route("/cert/apply")
def cert_apply():
    return _render("apply")


@app.route("/cert/do_apply", methods=["POST"])
def cert_do_apply():
    selected   = request.form.getlist("domain")
    custom_raw = request.form.get("custom_domains", "")
    custom     = [d.strip() for d in custom_raw.splitlines() if d.strip()]
    all_domains = list(dict.fromkeys(selected + custom))

    if not all_domains:
        return _json_or_redirect(False, "请至少选择一个域名", "cert_apply")

    ok, cert_id, msg = apply_and_verify_bg(",".join(all_domains))
    return _json_or_redirect(ok, msg, "cert_apply", cert_id=cert_id)


# ── 证书列表 ──────────────────────────────────────────────────────────────────
@app.route("/cert/list")
def cert_list():
    api_certs = list_api_certs()
    return _render("list", api_certs=api_certs)


@app.route("/cert/local")
def cert_local():
    return _render("local", local_cert_details=get_local_cert_details())


@app.route("/ops/logs")
def ops_logs_page():
    user_filter = request.args.get("user", "").strip()
    start_date = request.args.get("start_date", "").strip()
    end_date = request.args.get("end_date", "").strip()

    start_time = f"{start_date} 00:00:00" if start_date else ""
    end_time = f"{end_date} 23:59:59" if end_date else ""

    logs = _read_operation_logs(user_filter=user_filter, start_time=start_time, end_time=end_time)
    users = sorted({str(item.get("user", "")).strip() for item in _read_operation_logs(limit=1000) if str(item.get("user", "")).strip()})
    return _render(
        "ops_logs",
        operation_logs=logs,
        operation_log_users=users,
        log_filter={"user": user_filter, "start_date": start_date, "end_date": end_date}
    )


@app.route("/ops/logs/export")
def ops_logs_export_csv():
    user_filter = request.args.get("user", "").strip()
    start_date = request.args.get("start_date", "").strip()
    end_date = request.args.get("end_date", "").strip()

    start_time = f"{start_date} 00:00:00" if start_date else ""
    end_time = f"{end_date} 23:59:59" if end_date else ""
    logs = _read_operation_logs(limit=5000, user_filter=user_filter, start_time=start_time, end_time=end_time)

    csv_text = _build_ops_logs_csv(logs)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"operations_{ts}.csv"
    response = Response(csv_text, mimetype="text/csv; charset=utf-8")
    response.headers["Content-Disposition"] = f"attachment; filename={filename}"
    return response


@app.route("/cert/check")
def cert_check_page():
    return _render("cert_check", cert_check_domains=CERT_CHECK_DOMAINS)


@app.route("/cert/check/domain/add", methods=["POST"])
def cert_check_domain_add():
    domain = request.form.get("domain", "").strip().lower()
    if not domain:
        return _json_or_redirect(False, "域名不能为空", "cert_check_page")

    if domain in CERT_CHECK_DOMAINS:
        return _json_or_redirect(False, f"域名已存在：{domain}", "cert_check_page")

    _save_cert_check_domains(CERT_CHECK_DOMAINS + [domain])
    return _json_or_redirect(True, f"域名已添加：{domain}", "cert_check_page")


@app.route("/cert/check/domain/delete", methods=["POST"])
def cert_check_domain_delete():
    domain = request.form.get("domain", "").strip().lower()
    if not domain:
        return _json_or_redirect(False, "域名不能为空", "cert_check_page")

    if domain not in CERT_CHECK_DOMAINS:
        return _json_or_redirect(False, f"域名不存在：{domain}", "cert_check_page")

    _save_cert_check_domains([d for d in CERT_CHECK_DOMAINS if d != domain])
    return _json_or_redirect(True, f"域名已删除：{domain}", "cert_check_page")


@app.route("/cert/check/do", methods=["POST"])
def cert_check_do():
    domain = request.form.get("domain", "").strip()
    if domain not in CERT_CHECK_DOMAINS:
        return _json_or_redirect(False, f"不在预定义域名列表中：{domain}", "cert_check_page")

    cert_result = _check_domain_cert(domain)
    return _json_or_redirect(cert_result.get("ok", False), cert_result.get("message", "校验完成"), "cert_check_page", cert_result=cert_result)


@app.route("/cert/check/do_all", methods=["POST"])
def cert_check_do_all():
    cert_results = [_check_domain_cert(domain) for domain in CERT_CHECK_DOMAINS]
    ok_count = sum(1 for item in cert_results if item.get("ok"))
    msg = f"校验完成：成功 {ok_count}/{len(cert_results)}"
    return _json_or_redirect(True, msg, "cert_check_page", cert_results=cert_results)


@app.route("/cert/local/delete", methods=["POST"])
def cert_local_delete():
    domain = request.form.get("domain")
    ok, msg = delete_local_cert(domain)
    return _json_or_redirect(ok, msg, "cert_local", domain=domain)


@app.route("/cert/do_verify", methods=["POST"])
def cert_do_verify():
    cert_id = request.form.get("cert_id")
    ok, msg, dns_records = do_dns_verify(cert_id)
    return _json_or_redirect(ok, msg, "cert_list", dns_records=dns_records, cert_id=cert_id)


@app.route("/cert/do_download", methods=["POST"])
def cert_do_download():
    cert_id = request.form.get("cert_id")
    cert_type = request.form.get("download_type", "normal")
    ok, msg, domain = download_cert(cert_id, cert_type=cert_type)
    local_cert_details = get_local_cert_details()
    return _json_or_redirect(ok, msg, "cert_list", domain=domain, local_cert_details=local_cert_details)


@app.route("/cert/do_delete", methods=["POST"])
def cert_do_delete():
    cert_id = request.form.get("cert_id")
    ok, msg = delete_cert(cert_id)
    return _json_or_redirect(ok, msg, "cert_list", cert_id=cert_id)


# ── AWS 部署 ──────────────────────────────────────────────────────────────────
@app.route("/deploy/aws")
def deploy_aws():
    try:
        cfs = get_cloudfronts()
    except Exception as e:
        cfs = []
        flash(f"获取 CloudFront 失败：{e}", "danger")
    try:
        lbs = get_load_balancers()
    except Exception as e:
        lbs = []
        flash(f"获取 LoadBalancer 失败：{e}", "danger")
    iam_active_certs = _get_active_iam_certs()
    for cf in cfs:
        cf["suggested_cert_name"] = _pick_suggested_iam_cert_name(cf.get("current_cert_name"), iam_active_certs)
    for lb in lbs:
        lb["suggested_cert_name"] = _pick_suggested_iam_cert_name(lb.get("current_cert_name"), iam_active_certs)
    default_deploy_cert_name = _pick_suggested_iam_cert_name("", iam_active_certs)
    if not iam_active_certs:
        flash("当前没有可用于 AWS 部署的 IAM 证书，请先在 AWS IAM 证书页面上传未过期证书", "warning")
    return _render(
        "aws",
        cfs=cfs,
        lbs=lbs,
        iam_active_certs=iam_active_certs,
        default_deploy_cert_name=default_deploy_cert_name
    )


@app.route("/deploy/aws/do", methods=["POST"])
def deploy_aws_do():
    res_type    = request.form.get("type")
    res_id      = request.form.get("id")
    cert_name = request.form.get("cert")
    cert = _find_active_iam_cert(cert_name)
    if not cert:
        return _json_or_redirect(False, "请选择一个未过期的 IAM 证书", "deploy_aws")

    try:
        if res_type == "cloudfront":
            ok, msg = deploy_cf(res_id, cert.get("id"))
        elif res_type == "lb":
            ok, msg = deploy_lb(res_id, cert.get("arn"))
        else:
            ok, msg = False, f"未知类型：{res_type}"
    except Exception as e:
        ok, msg = False, str(e)

    return _json_or_redirect(ok, msg, "deploy_aws")


@app.route("/deploy/aws/do_all_cloudfront", methods=["POST"])
def deploy_aws_do_all_cloudfront():
    cert_name = request.form.get("cert")
    cert = _find_active_iam_cert(cert_name)
    if not cert:
        return _json_or_redirect(False, "请选择一个未过期的 IAM 证书", "deploy_aws")

    try:
        cfs = get_cloudfronts()
        if not cfs:
            return _json_or_redirect(False, "未获取到 CloudFront 分发", "deploy_aws")

        ok_count = 0
        fail_msgs = []

        for cf in cfs:
            ok, msg = deploy_cf(cf["id"], cert.get("id"))
            if ok:
                ok_count += 1
            else:
                fail_msgs.append(f"{cf.get('domain', cf['id'])}: {msg}")

        if fail_msgs:
            return _json_or_redirect(False, f"CloudFront 批量部署完成：成功 {ok_count}/{len(cfs)}；{'；'.join(fail_msgs[:5])}", "deploy_aws")
        else:
            return _json_or_redirect(True, f"CloudFront 批量部署成功：{ok_count}/{len(cfs)}", "deploy_aws")

    except Exception as e:
        return _json_or_redirect(False, f"CloudFront 批量部署失败：{e}", "deploy_aws")


@app.route("/deploy/aws/do_all_lb", methods=["POST"])
def deploy_aws_do_all_lb():
    cert_name = request.form.get("cert")
    cert = _find_active_iam_cert(cert_name)
    if not cert:
        return _json_or_redirect(False, "请选择一个未过期的 IAM 证书", "deploy_aws")

    try:
        lbs = get_load_balancers()
        if not lbs:
            return _json_or_redirect(False, "未获取到 LoadBalancer", "deploy_aws")

        ok_count = 0
        fail_msgs = []
        for lb in lbs:
            ok, msg = deploy_lb(lb["arn"], cert.get("arn"))
            if ok:
                ok_count += 1
            else:
                fail_msgs.append(f"{lb.get('name', lb['arn'])}: {msg}")

        if fail_msgs:
            return _json_or_redirect(False, f"LoadBalancer 批量部署完成：成功 {ok_count}/{len(lbs)}；{'；'.join(fail_msgs[:5])}", "deploy_aws")
        return _json_or_redirect(True, f"LoadBalancer 批量部署成功：{ok_count}/{len(lbs)}", "deploy_aws")
    except Exception as e:
        return _json_or_redirect(False, f"LoadBalancer 批量部署失败：{e}", "deploy_aws")


@app.route("/deploy/aws/iam")
def deploy_aws_iam_page():
    try:
        iam_certs = list_iam_certs_with_bindings()
    except Exception as e:
        iam_certs = []
        flash(f"获取 IAM 证书失败：{e}", "danger")
    return _render("aws_iam", iam_certs=iam_certs)


@app.route("/deploy/aws/iam/upload", methods=["POST"])
def deploy_aws_iam_upload():
    cert_domain = request.form.get("cert", "").strip()
    if not cert_domain:
        return _json_or_redirect(False, "请选择要上传的本地证书", "deploy_aws_iam_page")

    cert_path = os.path.join(CERT_SAVE_PATH, cert_domain)
    if not os.path.isdir(cert_path):
        return _json_or_redirect(False, f"本地证书目录不存在：{cert_domain}", "deploy_aws_iam_page")

    expire_date = _get_cert_expire_date(cert_domain)
    if not expire_date:
        return _json_or_redirect(False, "未找到证书到期时间，请先同步证书列表后重试", "deploy_aws_iam_page")

    try:
        upload_iam_cert(cert_path, expire_date)
        return _json_or_redirect(True, f"证书已上传到 IAM：{cert_domain}", "deploy_aws_iam_page")
    except Exception as e:
        return _json_or_redirect(False, f"上传到 IAM 失败：{e}", "deploy_aws_iam_page")


@app.route("/deploy/aws/iam/delete", methods=["POST"])
def deploy_aws_iam_delete():
    cert_name = request.form.get("cert_name", "").strip()
    if not cert_name:
        return _json_or_redirect(False, "缺少证书名称", "deploy_aws_iam_page")

    ok, msg = delete_iam_cert(cert_name)
    return _json_or_redirect(ok, msg, "deploy_aws_iam_page", cert_name=cert_name)


# ── Linux 部署 ────────────────────────────────────────────────────────────────
@app.route("/deploy/linux")
def deploy_linux_page():
    return _render("linux", linux=LINUX_SERVERS)


@app.route("/deploy/linux/server/save", methods=["POST"])
def deploy_linux_server_save():
    server = _normalize_linux_server(request.form)
    ok, msg = _validate_linux_server(server)
    if not ok:
        return _json_or_redirect(False, msg, "deploy_linux_page")

    original_host = (request.form.get("original_host") or "").strip()
    existing_server = next((s for s in LINUX_SERVERS if s.get("host") == original_host), None)
    if existing_server:
        for key in ("deployed_cert", "deployed_at", "last_deploy_at", "last_deploy_ok", "last_deploy_message"):
            if key in existing_server:
                server[key] = existing_server.get(key)

    ok, servers, msg = _upsert_server(LINUX_SERVERS, request.form.get("original_host"), server)
    if not ok:
        return _json_or_redirect(False, msg, "deploy_linux_page")

    _save_server_list("LINUX_SERVERS_JSON", LINUX_SERVERS, servers)
    return _json_or_redirect(True, msg, "deploy_linux_page")


@app.route("/deploy/linux/server/delete", methods=["POST"])
def deploy_linux_server_delete():
    ok, servers, msg = _delete_server(LINUX_SERVERS, request.form.get("host"))
    if not ok:
        return _json_or_redirect(False, msg, "deploy_linux_page")

    _save_server_list("LINUX_SERVERS_JSON", LINUX_SERVERS, servers)
    return _json_or_redirect(True, msg, "deploy_linux_page")


@app.route("/deploy/linux/do", methods=["POST"])
def deploy_linux_do():
    host        = request.form.get("host")
    cert_domain = request.form.get("cert")
    ok, msg     = _linux_deploy(host, cert_domain)
    _mark_linux_server_deploy_state(host, cert_domain, ok, msg)
    deploy_state = _get_server_deploy_state(LINUX_SERVERS, host)
    return _json_or_redirect(ok, msg, "deploy_linux_page", deploy_state=deploy_state)


@app.route("/deploy/linux/do_all", methods=["POST"])
def deploy_linux_do_all():
    cert_domain = request.form.get("cert", "").strip()
    if not cert_domain:
        return _json_or_redirect(False, "请选择要部署的证书", "deploy_linux_page")
    if not LINUX_SERVERS:
        return _json_or_redirect(False, "暂无 Linux 服务器", "deploy_linux_page")

    ok_count = 0
    fail_msgs = []
    touched_hosts = []
    for s in LINUX_SERVERS:
        host = s.get("host", "")
        ok, msg = _linux_deploy(host, cert_domain)
        _mark_linux_server_deploy_state(host, cert_domain, ok, msg)
        touched_hosts.append(host)
        if ok:
            ok_count += 1
        else:
            fail_msgs.append(f"{s.get('name', host)}: {msg}")

    deploy_states = []
    for host in touched_hosts:
        state = _get_server_deploy_state(LINUX_SERVERS, host)
        if state:
            deploy_states.append(state)

    if fail_msgs:
        return _json_or_redirect(False, f"Linux 批量部署完成：成功 {ok_count}/{len(LINUX_SERVERS)}；{'；'.join(fail_msgs[:5])}", "deploy_linux_page", deploy_states=deploy_states)
    return _json_or_redirect(True, f"Linux 批量部署成功：{ok_count}/{len(LINUX_SERVERS)}", "deploy_linux_page", deploy_states=deploy_states)


# ── IIS 部署 ──────────────────────────────────────────────────────────────────
@app.route("/deploy/iis")
def deploy_iis_page():
    return _render("iis", iis=IIS_SERVERS)


@app.route("/deploy/iis/server/save", methods=["POST"])
def deploy_iis_server_save():
    server = _normalize_iis_server(request.form)
    ok, msg = _validate_iis_server(server)
    if not ok:
        return _json_or_redirect(False, msg, "deploy_iis_page")

    original_host = (request.form.get("original_host") or "").strip()
    existing_server = next((s for s in IIS_SERVERS if s.get("host") == original_host), None)
    if existing_server:
        for key in ("deployed_cert", "deployed_at", "last_deploy_at", "last_deploy_ok", "last_deploy_message"):
            if key in existing_server:
                server[key] = existing_server.get(key)

    ok, servers, msg = _upsert_server(IIS_SERVERS, request.form.get("original_host"), server)
    if not ok:
        return _json_or_redirect(False, msg, "deploy_iis_page")

    _save_server_list("IIS_SERVERS_JSON", IIS_SERVERS, servers)
    return _json_or_redirect(True, msg, "deploy_iis_page")


@app.route("/deploy/iis/server/delete", methods=["POST"])
def deploy_iis_server_delete():
    ok, servers, msg = _delete_server(IIS_SERVERS, request.form.get("host"))
    if not ok:
        return _json_or_redirect(False, msg, "deploy_iis_page")

    _save_server_list("IIS_SERVERS_JSON", IIS_SERVERS, servers)
    return _json_or_redirect(True, msg, "deploy_iis_page")


@app.route("/deploy/iis/server/test", methods=["POST"])
def deploy_iis_server_test():
    host = request.form.get("host")
    ok, msg = _winrm_test(host)
    return _json_or_redirect(ok, msg, "deploy_iis_page")


@app.route("/deploy/iis/do", methods=["POST"])
def deploy_iis_do():
    host        = request.form.get("host")
    cert_domain = request.form.get("cert")
    ok, msg     = _winrm_deploy(host, cert_domain)
    _mark_iis_server_deploy_state(host, cert_domain, ok, msg)
    deploy_state = _get_server_deploy_state(IIS_SERVERS, host)
    return _json_or_redirect(ok, msg, "deploy_iis_page", deploy_state=deploy_state)


@app.route("/deploy/iis/do_all", methods=["POST"])
def deploy_iis_do_all():
    cert_domain = request.form.get("cert", "").strip()
    if not cert_domain:
        return _json_or_redirect(False, "请选择要部署的证书", "deploy_iis_page")
    if not IIS_SERVERS:
        return _json_or_redirect(False, "暂无 Windows IIS 服务器", "deploy_iis_page")

    ok_count = 0
    fail_msgs = []
    touched_hosts = []
    for s in IIS_SERVERS:
        host = s.get("host", "")
        ok, msg = _winrm_deploy(host, cert_domain)
        _mark_iis_server_deploy_state(host, cert_domain, ok, msg)
        touched_hosts.append(host)
        if ok:
            ok_count += 1
        else:
            fail_msgs.append(f"{s.get('name', host)}: {msg}")

    deploy_states = []
    for host in touched_hosts:
        state = _get_server_deploy_state(IIS_SERVERS, host)
        if state:
            deploy_states.append(state)

    if fail_msgs:
        return _json_or_redirect(False, f"IIS 批量部署完成：成功 {ok_count}/{len(IIS_SERVERS)}；{'；'.join(fail_msgs[:5])}", "deploy_iis_page", deploy_states=deploy_states)
    return _json_or_redirect(True, f"IIS 批量部署成功：{ok_count}/{len(IIS_SERVERS)}", "deploy_iis_page", deploy_states=deploy_states)


# ── 工具：部署到 Linux（支持本机直连 / SSH / 业务定制）───────────────────────
def _linux_deploy(host, cert_domain):
    server = next((s for s in LINUX_SERVERS if s["host"] == host), None)
    if not server:
        return False, f"未找到服务器 {host}"

    cert_dir = os.path.join(CERT_SAVE_PATH, cert_domain)
    if not os.path.isdir(cert_dir):
        return False, f"本地证书目录不存在：{cert_domain}"

    ssl_path = server.get("ssl_path", "/etc/nginx/ssl/")
    deploy_type = str(server.get("deploy_type", "nginx") or "nginx").strip().lower()

    canonical_fullchain = _pick_first_existing(cert_dir, ["fullchain.crt", "fullchain.pem", "certificate.crt", "cert.pem"])
    canonical_private = _pick_first_existing(cert_dir, ["private.pem", "privkey.pem"])
    if not canonical_fullchain or not canonical_private:
        return False, "本地证书目录缺少 fullchain 与 private 文件"
    key_type = _detect_private_key_type(canonical_private)

    def _local_copy_all_files():
        os.makedirs(ssl_path, exist_ok=True)
        copied = 0
        for fname in ("certificate.crt", "private.pem", "fullchain.crt", "chain.crt", "cert.pem", "privkey.pem", "fullchain.pem"):
            local_f = os.path.join(cert_dir, fname)
            if os.path.isfile(local_f):
                shutil.copy2(local_f, os.path.join(ssl_path, fname))
                copied += 1

        # 统一落一份固定文件名，便于后续脚本命令使用
        shutil.copy2(canonical_fullchain, os.path.join(ssl_path, "fullchain.crt"))
        shutil.copy2(canonical_fullchain, os.path.join(ssl_path, "fullchain.pem"))
        shutil.copy2(canonical_private, os.path.join(ssl_path, "private.pem"))
        shutil.copy2(canonical_private, os.path.join(ssl_path, "privkey.pem"))
        return copied

    def _remote_upload_all_files(ssh_client):
        remote_temp_dir = f"/tmp/autodevops-{datetime.now().strftime('%Y%m%d%H%M%S%f')}"
        sftp = ssh_client.open_sftp()
        try:
            ok_mkdir, out_mkdir = _run_ssh_shell(ssh_client, f"mkdir -p {_sh_quote(remote_temp_dir)}")
            if not ok_mkdir:
                raise RuntimeError(out_mkdir or "创建远端临时目录失败")
            for fname in ("certificate.crt", "private.pem", "fullchain.crt", "chain.crt", "cert.pem", "privkey.pem", "fullchain.pem"):
                local_f = os.path.join(cert_dir, fname)
                if os.path.isfile(local_f):
                    sftp.put(local_f, remote_temp_dir.rstrip("/") + "/" + fname)

            sftp.put(canonical_fullchain, remote_temp_dir.rstrip("/") + "/fullchain.crt")
            sftp.put(canonical_fullchain, remote_temp_dir.rstrip("/") + "/fullchain.pem")
            sftp.put(canonical_private, remote_temp_dir.rstrip("/") + "/private.pem")
            sftp.put(canonical_private, remote_temp_dir.rstrip("/") + "/privkey.pem")
        finally:
            sftp.close()
        return remote_temp_dir

    if _is_local_host(host):
        try:
            _local_copy_all_files()

            if deploy_type == "socket_server":
                cmd = " && ".join(_build_socket_server_commands(key_type))
                ok_run, out = _run_local_shell(cmd, work_dir=ssl_path)
                if not ok_run:
                    return False, f"SocketServer 部署失败：{out or '命令执行失败'}"
                return True, "本机 SocketServer 证书部署完成，eChat 服务已重启"

            ok_run, out = _run_local_shell("nginx -t && systemctl reload nginx")
            if not ok_run:
                return False, f"本机 Nginx 重载失败：{out or '命令执行失败'}"
            return True, "本机 Linux 证书部署完成，Nginx 已重载"
        except Exception as e:
            return False, f"本机部署失败：{e}"

    try:
        import paramiko
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        connect = {"hostname": server["host"], "username": server["user"]}
        if server.get("key"):
            connect["key_filename"] = server["key"]
        elif server.get("password"):
            connect["password"] = server["password"]

        ssh.connect(**connect)
        remote_temp_dir = _remote_upload_all_files(ssh)

        if deploy_type == "socket_server":
            cmd = f"cd {_sh_quote(remote_temp_dir)} && " + " && ".join(_build_socket_server_commands(key_type, ssl_path=ssl_path))
            ok_run, out = _run_ssh_shell(ssh, cmd)
            _run_ssh_shell(ssh, f"rm -rf {_sh_quote(remote_temp_dir)}")
            if not ok_run:
                ssh.close()
                return False, f"SocketServer 部署失败：{out or '命令执行失败'}"
            ssh.close()
            return True, f"证书已部署到 {server['name']}（SocketServer），eChat 服务已重启"

        if deploy_type == "gitlab":
            private_remote = remote_temp_dir.rstrip("/") + "/private.pem"
            fullchain_remote = remote_temp_dir.rstrip("/") + "/fullchain.crt"
            cmd = " && ".join(_build_gitlab_commands(private_remote, key_type, fullchain_remote, ssl_path))
            ok_run, out = _run_ssh_shell(ssh, cmd)
            _run_ssh_shell(ssh, f"rm -rf {_sh_quote(remote_temp_dir)}")
            if not ok_run:
                ssh.close()
                return False, f"GitLab 部署失败：{out or '命令执行失败'}"
            ssh.close()
            return True, f"证书已部署到 {server['name']}（GitLab），已执行 reconfigure/restart/status"

        sync_cmd = " && ".join([
            f"sudo -n mkdir -p {_sh_quote(ssl_path)}",
            f"sudo -n cp -f {_sh_quote(remote_temp_dir.rstrip('/') + '/fullchain.crt')} {_sh_quote(ssl_path.rstrip('/') + '/fullchain.crt')}",
            f"sudo -n cp -f {_sh_quote(remote_temp_dir.rstrip('/') + '/fullchain.pem')} {_sh_quote(ssl_path.rstrip('/') + '/fullchain.pem')}",
            f"sudo -n cp -f {_sh_quote(remote_temp_dir.rstrip('/') + '/private.pem')} {_sh_quote(ssl_path.rstrip('/') + '/private.pem')}",
            f"sudo -n cp -f {_sh_quote(remote_temp_dir.rstrip('/') + '/privkey.pem')} {_sh_quote(ssl_path.rstrip('/') + '/privkey.pem')}",
            "sudo -n nginx -t",
            "sudo -n systemctl reload nginx"
        ])
        ok_run, out = _run_ssh_shell(ssh, sync_cmd)
        _run_ssh_shell(ssh, f"rm -rf {_sh_quote(remote_temp_dir)}")
        ssh.close()
        if not ok_run:
            return False, f"Nginx 重载失败：{out or '命令执行失败'}"
        return True, f"证书已部署到 {server['name']}，Nginx 已重载"

    except ImportError:
        return False, "paramiko 未安装，请运行：pip install paramiko"
    except Exception as e:
        return False, f"SSH 部署失败：{str(e)}"


# ── 工具：WinRM 部署到 IIS ────────────────────────────────────────────────────
def _winrm_deploy(host, cert_domain):
    server = next((s for s in IIS_SERVERS if s["host"] == host), None)
    if not server:
        return False, f"未找到服务器 {host}"

    deploy_script = str(server.get("deploy_script", "") or "").strip()

    cert_dir = os.path.join(CERT_SAVE_PATH, cert_domain)
    if not os.path.isdir(cert_dir):
        return False, f"本地证书目录不存在：{cert_domain}"

    cert_expire_date = _get_cert_expire_date(cert_domain)

    version = str(server.get("version", "new") or "new").strip().lower()

    preferred_candidates = ["certificate_old.pfx", "certificate.pfx", "cert.pfx"] if version == "old" else ["certificate_new.pfx", "certificate.pfx", "cert.pfx"]

    pfx_path = ""
    for fname in preferred_candidates:
        candidate = os.path.join(cert_dir, fname)
        if os.path.isfile(candidate):
            pfx_path = candidate
            break
    if not pfx_path:
        pfx_candidates = [
            os.path.join(cert_dir, name)
            for name in os.listdir(cert_dir)
            if name.lower().endswith(".pfx") and os.path.isfile(os.path.join(cert_dir, name))
        ]
        pfx_path = sorted(pfx_candidates)[0] if pfx_candidates else ""

    if not pfx_path:
        return False, "IIS 部署需要 .pfx 文件，未在本地证书目录找到任何 .pfx 文件"

    def _read_text(path):
        for enc in ("utf-8", "gbk", "latin1"):
            try:
                with open(path, "r", encoding=enc) as f:
                    return f.read()
            except Exception:
                continue
        return ""

    def _extract_pfx_password(detail_text):
        if not detail_text:
            return ""
        lines = [line.strip() for line in detail_text.splitlines()]
        for idx, line in enumerate(lines):
            if not line:
                continue
            m = re.search(r"(?:pfx\s*)?(?:密码|password)\s*[:：]\s*(.*)$", line, flags=re.IGNORECASE)
            if not m:
                m = re.search(r"(?:pfx\s*)?(?:密码|password)\s*(?:is|为)\s*(.*)$", line, flags=re.IGNORECASE)
            if not m:
                continue
            pw = str(m.group(1) or "").strip().strip("'\"")
            if pw:
                return pw
            for next_line in lines[idx + 1:]:
                next_line = str(next_line or "").strip().strip("'\"")
                if next_line:
                    return next_line
        return ""

    pfx_password = ""
    for detail_name in ("detail.txt", "details.txt"):
        detail_path = os.path.join(cert_dir, detail_name)
        if os.path.isfile(detail_path):
            pfx_password = _extract_pfx_password(_read_text(detail_path))
            if pfx_password:
                break

    if not pfx_password:
        return False, "未读取到 PFX 密码，请在证书目录 detail.txt/details.txt 中提供 password: xxx"

    script_local_path = os.path.join(os.path.dirname(__file__), "deploy", "iis", "deploy-iis-cert.ps1")
    if not os.path.isfile(script_local_path):
        return False, f"未找到 IIS 部署脚本：{script_local_path}"

    with open(pfx_path, "rb") as f:
        pfx_b64 = base64.b64encode(f.read()).decode("ascii")
    with open(script_local_path, "rb") as f:
        script_b64 = base64.b64encode(f.read()).decode("ascii")

    def _decode_bytes(raw):
        for enc in ("utf-8", "gbk", "latin1"):
            try:
                return raw.decode(enc)
            except Exception:
                continue
        return str(raw)

    def _ps_quote(value):
        return str(value or "").replace("'", "''")

    try:
        protocol = str(server.get("protocol", "http") or "http").strip().lower()
        port = server.get("port", 5986 if protocol == "https" else 5985)
        reachable, reason = _check_tcp_connectivity(host, port, timeout=5)
        if not reachable:
            return False, f"无法连接 WinRM 端口 {host}:{port}（{reason}）"

        session, _, _ = _create_winrm_session(server)

        def _run_ps(script, fail_msg):
            res = session.run_ps(script)
            stdout = _clean_powershell_output(_decode_bytes(res.std_out))
            stderr = _clean_powershell_output(_decode_bytes(res.std_err))
            if res.status_code != 0:
                return False, (stderr or stdout or fail_msg)
            return True, stdout

        remote_token = datetime.now().strftime("%Y%m%d%H%M%S%f")
        temp_dir = "C:\\Script"
        remote_pfx_b64_path = f"{temp_dir}\\autodevops-{remote_token}.pfx.b64"
        remote_pfx_path = f"{temp_dir}\\autodevops-{remote_token}.pfx"
        remote_script_b64_path = f"{temp_dir}\\autodevops-{remote_token}.ps1.b64"
        remote_script_path = deploy_script or f"{temp_dir}\\deploy-iis-cert.ps1"

        init_script = f"""
$ErrorActionPreference = 'Stop'
$tempDir = '{temp_dir}'
if (!(Test-Path -Path $tempDir)) {{
    New-Item -Path $tempDir -ItemType Directory | Out-Null
}}
Set-Content -Path '{remote_pfx_b64_path}' -Value '' -NoNewline -Encoding Ascii
Set-Content -Path '{remote_script_b64_path}' -Value '' -NoNewline -Encoding Ascii
"""
        ok, err = _run_ps(init_script, "初始化远端临时目录失败")
        if not ok:
            return False, err

        chunk_size = 3000
        for idx in range(0, len(pfx_b64), chunk_size):
            chunk = pfx_b64[idx:idx + chunk_size]
            append_script = f"""
$ErrorActionPreference = 'Stop'
$chunk = '{chunk}'
Add-Content -Path '{remote_pfx_b64_path}' -Value $chunk -NoNewline -Encoding Ascii
"""
            ok, err = _run_ps(append_script, f"上传证书分块失败（块 {idx // chunk_size + 1}）")
            if not ok:
                return False, err

        for idx in range(0, len(script_b64), chunk_size):
            chunk = script_b64[idx:idx + chunk_size]
            append_script = f"""
$ErrorActionPreference = 'Stop'
$chunk = '{chunk}'
Add-Content -Path '{remote_script_b64_path}' -Value $chunk -NoNewline -Encoding Ascii
"""
            ok, err = _run_ps(append_script, f"上传部署脚本分块失败（块 {idx // chunk_size + 1}）")
            if not ok:
                return False, err

        execute_script = f"""
$ErrorActionPreference = 'Stop'
$pfxPassword = '{_ps_quote(pfx_password)}'
$targetDomain = '{_ps_quote(cert_domain)}'
    $certExpireDate = '{_ps_quote(cert_expire_date)}'
$pfxB64Path = '{remote_pfx_b64_path}'
$pfxPath = '{remote_pfx_path}'
$scriptB64Path = '{remote_script_b64_path}'
$scriptPath = '{_ps_quote(remote_script_path)}'

$scriptDir = Split-Path -Parent $scriptPath
if ($scriptDir -and !(Test-Path -Path $scriptDir)) {{
    New-Item -Path $scriptDir -ItemType Directory -Force | Out-Null
}}

$pfxBase64 = Get-Content -Path $pfxB64Path -Raw
[System.IO.File]::WriteAllBytes($pfxPath, [System.Convert]::FromBase64String($pfxBase64))

$scriptBase64 = Get-Content -Path $scriptB64Path -Raw
[System.IO.File]::WriteAllBytes($scriptPath, [System.Convert]::FromBase64String($scriptBase64))

if (!(Test-Path -Path $scriptPath)) {{
    throw ('部署脚本不存在: ' + $scriptPath)
}}

& $scriptPath -PfxPath $pfxPath -PfxPassword $pfxPassword -CertDomain $targetDomain -CertExpireDate $certExpireDate
if ($LASTEXITCODE -ne 0) {{
    throw ('部署脚本执行失败，退出码=' + $LASTEXITCODE)
}}

Remove-Item -Path $pfxB64Path -Force -ErrorAction SilentlyContinue
Remove-Item -Path $scriptB64Path -Force -ErrorAction SilentlyContinue
Remove-Item -Path $pfxPath -Force -ErrorAction SilentlyContinue
Write-Output ('SCRIPT_PATH=' + $scriptPath)
"""

        ok, output = _run_ps(execute_script, "调用 IIS 部署脚本失败")
        if ok:
            script_line = next((line for line in output.splitlines() if line.startswith("SCRIPT_PATH=")), "")
            script_path_display = script_line.split("=", 1)[1] if "=" in script_line else (deploy_script or "C:\\Certificate\\deploy-iis-cert.ps1")
            expire_line = next((line for line in output.splitlines() if line.startswith("CERT_EXPIRE_DATE=")), "")
            expire_display = expire_line.split("=", 1)[1] if "=" in expire_line else (cert_expire_date or "未知")
            deleted_line = next((line for line in output.splitlines() if line.startswith("DELETED_OLD_CERT_COUNT=")), "")
            deleted_count = deleted_line.split("=", 1)[1] if "=" in deleted_line else "0"
            pfx_name = os.path.basename(pfx_path)
            return True, f"IIS 证书部署成功：{server['name']}（{version}，WinRM-{protocol.upper()}）；证书到期日：{expire_display}；已上传文件：{pfx_name}；调用脚本：{script_path_display}；清理旧证书：{deleted_count} 个"
        return False, output
    except ImportError:
        return False, "pywinrm 未安装，请运行：pip install pywinrm"
    except Exception as e:
        return False, _format_winrm_error(host, port, _clean_powershell_output(str(e)))


def _winrm_test(host):
    server = next((s for s in IIS_SERVERS if s["host"] == host), None)
    if not server:
        return False, f"未找到服务器 {host}"

    def _decode_bytes(raw):
        for enc in ("utf-8", "gbk", "latin1"):
            try:
                return raw.decode(enc)
            except Exception:
                continue
        return str(raw)

    ps_script = """
$ErrorActionPreference = 'Stop'
$os = Get-CimInstance Win32_OperatingSystem
$hostname = $env:COMPUTERNAME
Write-Output ('HOST=' + $hostname)
Write-Output ('OS=' + $os.Caption)
Write-Output ('VERSION=' + $os.Version)
Write-Output ('BUILD=' + $os.BuildNumber)
"""

    try:
        protocol = str(server.get("protocol", "http") or "http").strip().lower()
        port = server.get("port", 5986 if protocol == "https" else 5985)
        reachable, reason = _check_tcp_connectivity(host, port, timeout=5)
        if not reachable:
            return False, f"无法连接 WinRM 端口 {host}:{port}（{reason}）"

        session, _, _ = _create_winrm_session(server)
        res = session.run_ps(ps_script)
        stdout = _clean_powershell_output(_decode_bytes(res.std_out))
        stderr = _clean_powershell_output(_decode_bytes(res.std_err))
        if res.status_code != 0:
            return False, stderr or stdout or "WinRM 测试失败"

        host_line = next((line for line in stdout.splitlines() if line.startswith("HOST=")), "")
        os_line = next((line for line in stdout.splitlines() if line.startswith("OS=")), "")
        version_line = next((line for line in stdout.splitlines() if line.startswith("VERSION=")), "")
        remote_host = host_line.split("=", 1)[1] if "=" in host_line else host
        remote_os = os_line.split("=", 1)[1] if "=" in os_line else "未知系统"
        remote_version = version_line.split("=", 1)[1] if "=" in version_line else "未知版本"
        return True, f"连接成功：{server['name']} ({remote_host})，WinRM-{protocol.upper()}，系统：{remote_os}，版本：{remote_version}"
    except ImportError:
        return False, "pywinrm 未安装，请运行：pip install pywinrm"
    except Exception as e:
        return False, _format_winrm_error(host, port, str(e))


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=PORT, debug=APP_DEBUG)