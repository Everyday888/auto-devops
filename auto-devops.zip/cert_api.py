import requests
import os
import json
import zipfile
import time
import threading
import shutil
from datetime import datetime, timezone, timedelta
from config import *
from aws_real import upsert_dns_txt

_HEADERS = {"Authorization": f"Bearer {LE_API_KEY}:{LE_API_EMAIL}"}
_ORDER_API_BASE = "https://api.xwamp.com/api/user/Order/"
_DETAIL_API_BASE = "https://api.xwamp.com/api/user/OrderDetail/"
_CST_TZ = timezone(timedelta(hours=8))


def _parse_time_end(value):
    text = str(value or "").strip()
    if not text:
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            return datetime.strptime(text, fmt)
        except Exception:
            continue
    return None


def _normalize_cert_item(item):
    """标准化证书列表项，确保模板可直接渲染。"""
    domains = item.get("domains", "")
    if isinstance(domains, list):
        domains = ",".join(str(d).strip() for d in domains if str(d).strip())
    elif domains is None:
        domains = ""
    else:
        domains = str(domains)

    status_raw = item.get("status")
    status_map = {
        6: "完成",
        "6": "完成",
        2: "需要验证",
        "2": "需要验证",
        3: "验证中",
        "3": "验证中",
        4: "验证中",
        "4": "验证中",
        5: "验证中",
        "5": "验证中"
    }
    status = status_map.get(status_raw, str(status_raw) if status_raw is not None else "未知")

    normalized = dict(item)
    normalized["domains"] = domains
    normalized["status"] = status

    expire_dt = _parse_time_end(item.get("time_end") or item.get("expire_date"))
    if expire_dt is not None:
        normalized["expire_days"] = (expire_dt - datetime.now()).days
    else:
        normalized["expire_days"] = None

    return normalized


def _api_get(base_url, endpoint, **params):
    """调用证书 API GET 接口，返回 JSON"""
    r = requests.get(base_url + endpoint, headers=_HEADERS, params=params, timeout=60)
    return r.json()


# ── 证书列表（来自 API）─────────────────────────────────────────────────────────

def list_api_certs():
    """从 osfipin API 获取证书列表，每项含 id/status/domains/time_add/time_end"""
    try:
        data = _api_get(_ORDER_API_BASE, "list")
        if data.get("isError") is False:
            certs = data.get("data", {}).get("list", [])
            return [_normalize_cert_item(c) for c in certs]
        # 兼容旧返回结构
        if data.get("c") == 20:
            v = data.get("v", {})
            certs = v.get("list", []) if isinstance(v, dict) else []
            return [_normalize_cert_item(c) for c in certs]
        return []
    except Exception as e:
        print(f"[list_api_certs] {e}")
        return []


# ── 申请证书 ────────────────────────────────────────────────────────────────────

def apply_cert(domains_str):
    """
    申请 SAN 证书.
    domains_str: 逗号分隔域名, e.g. "infrontsmart.com,*.infrontsmart.com"
    返回 (ok, cert_id, msg)
    """
    try:
        data = _api_get(_ORDER_API_BASE, "apply", domain=domains_str)
        if data.get("isOk"):
            cert_id = str(data.get("data", {}).get("id", ""))
            return True, cert_id, "申请已提交"
        # 兼容旧返回结构
        if data.get("c") == 20:
            return True, str(data.get("v")), "申请已提交"
        return False, None, f"申请失败：{data.get('m', '')}"
    except Exception as e:
        return False, None, f"网络错误：{str(e)}"


# ── 证书详情 ────────────────────────────────────────────────────────────────────

def get_cert_detail(cert_id):
    """返回 (ok, detail_dict)，detail 含 verify_data"""
    try:
        data = _api_get(_DETAIL_API_BASE, "info", id=cert_id)
        if data.get("isOk"):
            return True, data.get("data", {})
        # 兼容旧返回结构
        if data.get("c") == 20:
            return True, data.get("v", {})
        return False, None
    except Exception as e:
        print(f"[get_cert_detail] {e}")
        return False, None


# ── DNS 写入 + 触发验证 ─────────────────────────────────────────────────────────

def do_dns_verify(cert_id):
    """
    1. 获取证书详情拿 DNS 挑战数据
    2. 写入 Route53 TXT 记录
    3. 调用 osfipin verify 接口
    返回 (ok, msg, dns_records)
    dns_records = [{record, value, route53_ok, route53_msg, status}, ...]
    """
    ok, detail = get_cert_detail(cert_id)
    if not ok or not detail:
        return False, "获取证书详情失败", []

    verify_data = detail.get("verify_data", [])
    dns_records = []
    verify_set_parts = []
    seen_records = set()

    for item in verify_data:
        dns_check   = item.get("check", {}).get("dns-01", {})
        record_name = dns_check.get("dns", "")
        txt_value   = dns_check.get("txt", "")
        status      = dns_check.get("status", "pending")

        entry = {
            "record": record_name,
            "value": txt_value,
            "route53_ok": None,
            "route53_msg": "",
            "status": status
        }

        if status == "pending" and record_name not in seen_records:
            seen_records.add(record_name)
            verify_set_parts.append(f"{item['id']}:dns-01")
            # _acme-challenge.xxx.yyy → xxx.yyy
            base_domain = record_name.split("_acme-challenge.", 1)[-1] if "_acme-challenge." in record_name else record_name
            r_ok, r_msg = upsert_dns_txt(base_domain, record_name, txt_value)
            entry["route53_ok"]  = r_ok
            entry["route53_msg"] = r_msg
        else:
            entry["route53_ok"]  = True
            entry["route53_msg"] = "已通过/跳过"

        dns_records.append(entry)

    if verify_set_parts:
        verify_str = ";".join(verify_set_parts)
        try:
            vdata = _api_get(_DETAIL_API_BASE, "verify", id=cert_id, set=verify_str)
            ok_verify = bool(vdata.get("isOk") or vdata.get("c") == 20)
            msg = "DNS验证已触发，约30分钟后完成" if ok_verify else f"触发失败：{vdata.get('error') or vdata.get('m', '')}"
        except Exception as e:
            msg = f"触发验证网络错误：{str(e)}"
    else:
        msg = "无 pending 记录，无需重新验证"

    return True, msg, dns_records


def _bg_verify(cert_id):
    """后台线程：等待30秒后自动触发 DNS 验证"""
    time.sleep(30)
    do_dns_verify(cert_id)


def apply_and_verify_bg(domains_str):
    """申请证书并在后台自动触发 DNS 验证，立即返回 (ok, cert_id, msg)"""
    ok, cert_id, msg = apply_cert(domains_str)
    if ok:
        threading.Thread(target=_bg_verify, args=(cert_id,), daemon=True).start()
        msg = f"申请已提交（ID: {cert_id}），30秒后自动写入 Route53 并触发验证"
    return ok, cert_id, msg


# ── 下载证书 ────────────────────────────────────────────────────────────────────

def download_cert(cert_id, cert_type="normal"):
    """
    下载证书 zip 并解压到 certs/{cert_id}/
    cert_type: normal 或 pfx
    返回 (ok, msg, cert_id)
    """
    try:
        cert_type = str(cert_type or "normal").strip().lower()
        if cert_type not in {"normal", "pfx"}:
            return False, f"不支持的下载格式：{cert_type}", ""

        r = requests.get(_DETAIL_API_BASE + "down", headers=_HEADERS, params={"type": cert_type, "id": cert_id}, timeout=60)
        # JSON 响应说明下载失败
        try:
            err = r.json()
            return False, f"下载失败：{err.get('error') or err.get('m', '')}", ""
        except Exception:
            pass

        os.makedirs(CERT_SAVE_PATH, exist_ok=True)
        zip_path = os.path.join(CERT_SAVE_PATH, f"_tmp_{cert_id}.zip")
        with open(zip_path, "wb") as f:
            f.write(r.content)

        # 证书目录固定使用 cert_id，便于唯一定位
        cert_id_str = str(cert_id).strip()
        primary_domain = cert_id_str
        for c in list_api_certs():
            if str(c.get("id")) == str(cert_id):
                primary_domain = str(c.get("domains", cert_id_str)).split(",")[0].strip().lstrip("*.")
                break

        extract_path = os.path.join(CERT_SAVE_PATH, cert_id_str)
        os.makedirs(extract_path, exist_ok=True)
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(extract_path)

        meta = {
            "cert_id": cert_id,
            "domain": primary_domain,
            "downloaded_at": datetime.now(_CST_TZ).strftime("%Y-%m-%d %H:%M:%S CST")
        }
        with open(os.path.join(extract_path, "meta.json"), "w", encoding="utf-8") as f:
            json.dump(meta, f)

        os.remove(zip_path)
        format_text = "PFX" if cert_type == "pfx" else "通用格式"
        return True, f"{format_text}证书已下载到 certs/{cert_id_str}/", cert_id_str

    except Exception as e:
        return False, f"下载异常：{str(e)}", ""


# ── 删除证书 ────────────────────────────────────────────────────────────────────

def delete_cert(cert_id):
    try:
        data = _api_get(_ORDER_API_BASE, "delete", id=cert_id)
        if data.get("isOk"):
            return True, "删除成功"
        if data.get("c") == 20:
            return True, "删除成功"
        return False, f"删除失败：{data.get('m', '')}"
    except Exception as e:
        return False, f"网络错误：{str(e)}"


# ── 本地已下载证书 ──────────────────────────────────────────────────────────────

def get_local_certs():
    """扫描 certs/ 目录，返回已下载的证书域名字符串列表（供部署界面选择）"""
    result = []
    if not os.path.isdir(CERT_SAVE_PATH):
        return result
    for d in sorted(os.listdir(CERT_SAVE_PATH)):
        full = os.path.join(CERT_SAVE_PATH, d)
        if not os.path.isdir(full):
            continue
        # 支持两种命名：osfipin zip 格式 和 旧版 .pem 格式
        if any(os.path.isfile(os.path.join(full, f)) for f in ("certificate.crt", "cert.pem")):
            result.append(d)
    return result


def get_local_pfx_certs():
    """扫描 certs/ 目录，返回包含 pfx 文件的证书目录列表（供 IIS 部署选择）。"""
    result = []
    if not os.path.isdir(CERT_SAVE_PATH):
        return result
    for d in sorted(os.listdir(CERT_SAVE_PATH)):
        full = os.path.join(CERT_SAVE_PATH, d)
        if not os.path.isdir(full):
            continue
        has_pfx = any(
            os.path.isfile(os.path.join(full, name)) and name.lower().endswith(".pfx")
            for name in os.listdir(full)
        )
        if has_pfx:
            result.append(d)
    return result


def get_local_cert_details():
    """返回本地证书详情列表，供页面展示。"""
    result = []
    if not os.path.isdir(CERT_SAVE_PATH):
        return result

    for d in sorted(os.listdir(CERT_SAVE_PATH)):
        full = os.path.join(CERT_SAVE_PATH, d)
        if not os.path.isdir(full):
            continue

        files = sorted(
            name for name in os.listdir(full)
            if os.path.isfile(os.path.join(full, name))
        )
        if not files:
            continue

        downloaded_at = ""
        meta_path = os.path.join(full, "meta.json")
        if os.path.isfile(meta_path):
            try:
                with open(meta_path, "r", encoding="utf-8") as f:
                    meta = json.load(f)
                    downloaded_at = str(meta.get("downloaded_at", ""))
            except Exception:
                downloaded_at = ""

        result.append({
            "domain": d,
            "path": os.path.join(CERT_SAVE_PATH, d).replace("\\", "/"),
            "downloaded_at": downloaded_at,
            "files": files
        })

    return result


def delete_local_cert(domain):
    """删除本地证书目录。"""
    if not domain:
        return False, "缺少证书目录名"

    cert_dir = os.path.join(CERT_SAVE_PATH, domain)
    if not os.path.isdir(cert_dir):
        return False, f"本地证书不存在：{domain}"

    try:
        shutil.rmtree(cert_dir)
        return True, f"本地证书已删除：{domain}"
    except Exception as e:
        return False, f"删除本地证书失败：{str(e)}"