import json
import os


def _strip_env_quotes(value):
    value = value.strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
        return value[1:-1]
    return value


def _load_local_env():
    env_path = os.path.join(os.path.dirname(__file__), ".env")
    if not os.path.isfile(env_path):
        return

    try:
        with open(env_path, "r", encoding="utf-8") as env_file:
            for raw_line in env_file:
                line = raw_line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue

                key, value = line.split("=", 1)
                key = key.strip()
                if not key or key in os.environ:
                    continue

                os.environ[key] = _strip_env_quotes(value)
    except Exception:
        pass


_load_local_env()


def _as_bool(value, default=False):
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


def _as_int(value, default):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _as_json_list(value, default):
    if not value:
        return default
    try:
        data = json.loads(value)
        return data if isinstance(data, list) else default
    except Exception:
        return default


def _as_csv_list(value, default):
    if not value:
        return default
    items = [item.strip() for item in value.split(",") if item.strip()]
    return items or default


PORT = _as_int(os.getenv("PORT"), 51749)
APP_DEBUG = _as_bool(os.getenv("APP_DEBUG"), False)
CERT_SAVE_PATH = os.getenv("CERT_SAVE_PATH", "./certs")

# 登录
APP_SECRET_KEY = os.getenv("APP_SECRET_KEY", "change-me")
LOGIN_USERNAME = os.getenv("LOGIN_USERNAME", "admin")
LOGIN_PASSWORD = os.getenv("LOGIN_PASSWORD", "change-me")

# 你的域名（优先读取 DOMAINS_JSON，其次 DOMAINS_CSV）
_default_domains = [
    "infrontsmart.com",
    "*.infrontsmart.com",
    "infrontsmart.cn",
    "*.infrontsmart.cn",
    "uquai.com",
    "*.uquai.com",
    "chbevpro.com",
    "*.chbevpro.com"
]
DOMAINS = _as_json_list(os.getenv("DOMAINS_JSON"), _default_domains)
if DOMAINS == _default_domains:
    DOMAINS = _as_csv_list(os.getenv("DOMAINS_CSV"), _default_domains)

# 证书校验预置域名
_default_cert_check_domains = [
    "oa.infrontsmart.com",
    "yx.infrontsmart.cn",
    "www.infrontsmart.com",
    "ew.infrontsmart.com",
    "ifs.infrontsmart.com"
]
CERT_CHECK_DOMAINS = _as_csv_list(os.getenv("CERT_CHECK_DOMAINS_CSV"), _default_cert_check_domains)

# 证书API
LE_API_KEY = os.getenv("LE_API_KEY", "")
LE_API_EMAIL = os.getenv("LE_API_EMAIL", "")

# AWS
AWS_ACCESS_KEY = os.getenv("AWS_ACCESS_KEY", "")
AWS_SECRET_KEY = os.getenv("AWS_SECRET_KEY", "")
AWS_REGION = os.getenv("AWS_REGION", "cn-northwest-1")

# Linux 服务器（使用 JSON 环境变量，示例见 .env.example）
LINUX_SERVERS = _as_json_list(os.getenv("LINUX_SERVERS_JSON"), [])

# IIS 服务器（使用 JSON 环境变量，示例见 .env.example）
IIS_SERVERS = _as_json_list(os.getenv("IIS_SERVERS_JSON"), [])