import os
import re
import boto3
from datetime import datetime, timezone
from botocore.exceptions import ClientError
from config import AWS_ACCESS_KEY, AWS_SECRET_KEY, AWS_REGION

# ✅ 正确创建 session（密钥从 config 来）
def get_session():
    return boto3.Session(
        aws_access_key_id=AWS_ACCESS_KEY,
        aws_secret_access_key=AWS_SECRET_KEY,
        region_name=AWS_REGION
    )


def _list_iam_server_cert_metadata():
    session = get_session()
    iam = session.client("iam")
    certs = []
    marker = None
    while True:
        kwargs = {}
        if marker:
            kwargs["Marker"] = marker
        resp = iam.list_server_certificates(**kwargs)
        certs.extend(resp.get("ServerCertificateMetadataList", []))
        if not resp.get("IsTruncated"):
            break
        marker = resp.get("Marker")
    return certs


def _get_iam_cert_lookup():
    metadata = _list_iam_server_cert_metadata()
    by_id = {}
    by_arn = {}
    for item in metadata:
        name = item.get("ServerCertificateName", "")
        cert_id = item.get("ServerCertificateId", "")
        arn = item.get("Arn", "")
        if cert_id:
            by_id[cert_id] = name
        if arn:
            by_arn[arn] = name
    return by_id, by_arn


def _format_cloudfront_cert_name(viewer_cert, iam_by_id):
    if not viewer_cert:
        return "-"
    if viewer_cert.get("CloudFrontDefaultCertificate"):
        return "CloudFront Default"

    iam_cert_id = viewer_cert.get("IAMCertificateId") or viewer_cert.get("Certificate")
    if iam_cert_id:
        return iam_by_id.get(iam_cert_id, iam_cert_id)

    acm_arn = viewer_cert.get("ACMCertificateArn")
    if acm_arn:
        return f"ACM: {acm_arn.split('/')[-1]}"

    return "-"


def _format_lb_cert_name(cert_arn, iam_by_arn):
    if not cert_arn:
        return "-"
    return iam_by_arn.get(cert_arn, cert_arn.split("/")[-1] if "/" in cert_arn else cert_arn)


def _format_lb_current_cert_display(listener_certs):
    if not listener_certs:
        return "-"
    return " | ".join(
        f"{item['port']}:{item['cert_name']}" if item.get("port") is not None else item["cert_name"]
        for item in listener_certs
    )

# 获取真实 LoadBalancers（返回规范化列表）
def get_load_balancers():
    session = get_session()
    elbv2 = session.client("elbv2")
    _, iam_by_arn = _get_iam_cert_lookup()
    lbs = elbv2.describe_load_balancers()["LoadBalancers"]
    result = []
    for lb in lbs:
        current_cert_name = "-"
        current_cert_arn = ""
        listener_cert_items = []
        for listener in _iter_listeners(elbv2, lb["LoadBalancerArn"]):
            certificates = listener.get("Certificates", [])
            if not certificates:
                continue

            cert_arn = certificates[0].get("CertificateArn", "")
            cert_name = _format_lb_cert_name(cert_arn, iam_by_arn)
            listener_cert_items.append({
                "port": listener.get("Port"),
                "protocol": listener.get("Protocol", ""),
                "cert_arn": cert_arn,
                "cert_name": cert_name
            })

            if listener.get("Port") == 443 and cert_arn:
                current_cert_arn = cert_arn
                current_cert_name = cert_name

        if current_cert_name == "-" and listener_cert_items:
            current_cert_arn = listener_cert_items[0].get("cert_arn", "")
            current_cert_name = listener_cert_items[0].get("cert_name", "-")

        result.append({
            "name": lb["LoadBalancerName"],
            "arn": lb["LoadBalancerArn"],
            "dns": lb["DNSName"],
            "status": lb.get("State", {}).get("Code", "unknown"),
            "current_cert_name": current_cert_name,
            "current_cert_arn": current_cert_arn,
            "current_cert_display": _format_lb_current_cert_display(listener_cert_items)
        })
    return result

# 获取真实 CloudFront（返回规范化列表）
def get_cloudfronts():
    session = get_session()
    cf = session.client("cloudfront")
    iam_by_id, _ = _get_iam_cert_lookup()
    items = cf.list_distributions()["DistributionList"].get("Items", [])
    result = []
    for item in items:
        viewer_cert = item.get("ViewerCertificate", {})
        result.append({
            "id": item["Id"],
            "domain": item["DomainName"],
            "status": item["Status"],
            "current_cert_name": _format_cloudfront_cert_name(viewer_cert, iam_by_id)
        })
    return result


def _to_text_time(value):
    if not value:
        return ""
    try:
        return value.strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return str(value)


def _iter_load_balancers(elbv2):
    marker = None
    while True:
        kwargs = {}
        if marker:
            kwargs["Marker"] = marker
        resp = elbv2.describe_load_balancers(**kwargs)
        for lb in resp.get("LoadBalancers", []):
            yield lb
        marker = resp.get("NextMarker")
        if not marker:
            break


def _iter_listeners(elbv2, lb_arn):
    marker = None
    while True:
        kwargs = {"LoadBalancerArn": lb_arn}
        if marker:
            kwargs["Marker"] = marker
        resp = elbv2.describe_listeners(**kwargs)
        for listener in resp.get("Listeners", []):
            yield listener
        marker = resp.get("NextMarker")
        if not marker:
            break


def _describe_listener_certificates(elbv2, listener):
    """统一读取监听器证书，优先覆盖 SNI 列表，失败时回退到监听器默认字段。"""
    certs = []
    marker = None
    while True:
        kwargs = {"ListenerArn": listener.get("ListenerArn")}
        if marker:
            kwargs["Marker"] = marker
        try:
            resp = elbv2.describe_listener_certificates(**kwargs)
        except ClientError:
            if listener.get("Certificates"):
                return [
                    {
                        "CertificateArn": cert.get("CertificateArn"),
                        "IsDefault": True
                    }
                    for cert in listener.get("Certificates", [])
                    if cert.get("CertificateArn")
                ]
            return []

        certs.extend(resp.get("Certificates", []))
        marker = resp.get("NextMarker")
        if not marker:
            break
    return certs


def _get_live_cert_bindings(cert_arn, only_lb_arn=None):
    """实时扫描 ALB/NLB 监听器，返回指定证书的绑定信息。"""
    session = get_session()
    elbv2 = session.client("elbv2")
    bindings = []

    load_balancers = []
    if only_lb_arn:
        resp = elbv2.describe_load_balancers(LoadBalancerArns=[only_lb_arn])
        load_balancers = resp.get("LoadBalancers", [])
    else:
        load_balancers = list(_iter_load_balancers(elbv2))

    for lb in load_balancers:
        lb_name = lb.get("LoadBalancerName", "")
        lb_arn = lb.get("LoadBalancerArn", "")
        for listener in _iter_listeners(elbv2, lb_arn):
            port = listener.get("Port")
            for cert in _describe_listener_certificates(elbv2, listener):
                if cert.get("CertificateArn") != cert_arn:
                    continue
                bindings.append({
                    "lb_name": lb_name,
                    "lb_arn": lb_arn,
                    "port": port,
                    "bind_type": "默认" if cert.get("IsDefault") else "SNI",
                    "listener_arn": listener.get("ListenerArn", "")
                })

    bindings.sort(key=lambda item: (
        item.get("lb_name", ""),
        item.get("port") if item.get("port") is not None else -1,
        item.get("bind_type", ""),
        item.get("listener_arn", "")
    ))
    return bindings


def _split_bindings(bindings):
    default_bindings = [b for b in bindings if b.get("bind_type") == "默认"]
    sni_bindings = [b for b in bindings if b.get("bind_type") == "SNI"]
    return default_bindings, sni_bindings


def _remove_sni_bindings(elbv2, cert_arn, bindings):
    removed = 0
    seen = set()
    for binding in bindings:
        if binding.get("bind_type") != "SNI":
            continue
        listener_arn = binding.get("listener_arn", "")
        if not listener_arn or listener_arn in seen:
            continue
        elbv2.remove_listener_certificates(
            ListenerArn=listener_arn,
            Certificates=[{"CertificateArn": cert_arn}]
        )
        seen.add(listener_arn)
        removed += 1
    return removed


def _extract_lb_arn_from_delete_error(message):
    if not message:
        return ""
    match = re.search(r"(arn:aws[^\s]+:loadbalancer/[^\s.]+)", message)
    return match.group(1) if match else ""


def _get_lb_cert_binding_map():
    """返回证书 ARN -> 绑定信息列表（含 LB 名称、端口、绑定类型）。"""
    binding_map = {}

    session = get_session()
    elbv2 = session.client("elbv2")
    for lb in _iter_load_balancers(elbv2):
        lb_name = lb.get("LoadBalancerName", "")
        lb_arn = lb.get("LoadBalancerArn", "")
        for listener in _iter_listeners(elbv2, lb_arn):
            port = listener.get("Port")
            for cert in _describe_listener_certificates(elbv2, listener):
                cert_arn = cert.get("CertificateArn")
                if not cert_arn:
                    continue
                bind_type = "默认" if cert.get("IsDefault") else "SNI"
                binding_map.setdefault(cert_arn, set()).add((
                    lb_name,
                    port,
                    bind_type,
                    listener.get("ListenerArn", ""),
                    lb_arn
                ))

    result = {}
    for arn, pairs in binding_map.items():
        result[arn] = [
            {
                "lb_name": lb_name,
                "lb_arn": lb_arn,
                "port": port,
                "bind_type": bind_type,
                "listener_arn": listener_arn
            }
            for lb_name, port, bind_type, listener_arn, lb_arn in sorted(
                pairs,
                key=lambda x: (x[0], x[1] if x[1] is not None else -1, x[2], x[3], x[4])
            )
        ]
    return result


def _get_cloudfront_cert_binding_map():
    """返回 IAM 证书 ID -> CloudFront 绑定信息列表。"""
    session = get_session()
    cf = session.client("cloudfront")
    binding_map = {}

    marker = None
    while True:
        kwargs = {}
        if marker:
            kwargs["Marker"] = marker

        resp = cf.list_distributions(**kwargs)
        dist_list = resp.get("DistributionList", {})
        for item in dist_list.get("Items", []):
            viewer_cert = item.get("ViewerCertificate", {})
            cert_id = viewer_cert.get("IAMCertificateId") or viewer_cert.get("Certificate")
            if not cert_id:
                continue
            binding_map.setdefault(cert_id, []).append({
                "id": item.get("Id", ""),
                "domain": item.get("DomainName", ""),
                "status": item.get("Status", "")
            })

        if not dist_list.get("IsTruncated"):
            break
        marker = dist_list.get("NextMarker")

    for cert_id in binding_map:
        binding_map[cert_id].sort(key=lambda item: (item.get("domain", ""), item.get("id", "")))
    return binding_map


def _is_expired(expiration):
    if not expiration:
        return False
    try:
        if expiration.tzinfo is None:
            expiration = expiration.replace(tzinfo=timezone.utc)
        return expiration <= datetime.now(timezone.utc)
    except Exception:
        return False


def list_iam_certs_with_bindings():
    """列出 IAM Server Certificates，并标记是否绑定到 LoadBalancer。"""
    session = get_session()
    iam = session.client("iam")

    certs = []
    marker = None
    while True:
        kwargs = {}
        if marker:
            kwargs["Marker"] = marker
        resp = iam.list_server_certificates(**kwargs)
        certs.extend(resp.get("ServerCertificateMetadataList", []))
        if not resp.get("IsTruncated"):
            break
        marker = resp.get("Marker")

    try:
        binding_map = _get_lb_cert_binding_map()
    except Exception:
        binding_map = {}
    try:
        cloudfront_binding_map = _get_cloudfront_cert_binding_map()
    except Exception:
        cloudfront_binding_map = {}

    result = []
    for c in certs:
        arn = c.get("Arn", "")
        cert_id = c.get("ServerCertificateId", "")
        expiration = c.get("Expiration")
        lb_bindings = binding_map.get(arn, [])
        cloudfront_bindings = cloudfront_binding_map.get(cert_id, [])
        lb_names = sorted({b.get("lb_name", "") for b in lb_bindings if b.get("lb_name")})
        default_bindings = [b for b in lb_bindings if b.get("bind_type") == "默认"]
        sni_bindings = [b for b in lb_bindings if b.get("bind_type") == "SNI"]
        is_expired = _is_expired(expiration)
        has_default_binding = bool(default_bindings)
        has_sni_binding = bool(sni_bindings)
        has_cloudfront_binding = bool(cloudfront_bindings)
        can_delete = is_expired and not has_default_binding and not has_cloudfront_binding
        result.append({
            "name": c.get("ServerCertificateName", ""),
            "id": cert_id,
            "arn": arn,
            "path": c.get("Path", ""),
            "upload_date": _to_text_time(c.get("UploadDate")),
            "expiration": _to_text_time(expiration),
            "is_expired": is_expired,
            "lb_bound": bool(lb_bindings),
            "lb_bindings": lb_bindings,
            "default_bindings": default_bindings,
            "sni_bindings": sni_bindings,
            "cloudfront_bound": has_cloudfront_binding,
            "cloudfront_bindings": cloudfront_bindings,
            "lb_names": lb_names,
            "has_default_binding": has_default_binding,
            "has_sni_binding": has_sni_binding,
            "has_cloudfront_binding": has_cloudfront_binding,
            "can_delete": can_delete
        })

    result.sort(key=lambda x: x.get("upload_date", ""), reverse=True)
    return result


def delete_iam_cert(server_certificate_name):
    session = get_session()
    iam = session.client("iam")
    elbv2 = session.client("elbv2")

    certs = list_iam_certs_with_bindings()
    target = next((c for c in certs if c.get("name") == server_certificate_name), None)
    if not target:
        return False, f"未找到 IAM 证书：{server_certificate_name}"
    if not target.get("is_expired"):
        return False, "该证书未过期，不允许删除"
    if target.get("has_cloudfront_binding"):
        return False, "该证书仍被 CloudFront 使用，请先在对应分发中替换证书后再删除"

    live_bindings = _get_live_cert_bindings(target.get("arn", ""))
    live_default_bindings, live_sni_bindings = _split_bindings(live_bindings)
    if live_default_bindings:
        return False, "该证书仍被某个监听器作为默认证书使用，请先替换默认 HTTPS 证书后再删除"

    removed_sni = _remove_sni_bindings(elbv2, target.get("arn", ""), live_sni_bindings)

    try:
        iam.delete_server_certificate(ServerCertificateName=server_certificate_name)
        if removed_sni:
            return True, f"已先移除 {removed_sni} 个 SNI 绑定，并删除 IAM 证书：{server_certificate_name}"
        return True, f"IAM 证书已删除：{server_certificate_name}"
    except ClientError as e:
        msg = e.response.get("Error", {}).get("Message", str(e))
        if "currently in use by" in msg:
            lb_arn = _extract_lb_arn_from_delete_error(msg)
            conflict_bindings = _get_live_cert_bindings(target.get("arn", ""), only_lb_arn=lb_arn or None)
            default_bindings, sni_bindings = _split_bindings(conflict_bindings)

            if sni_bindings:
                removed_sni += _remove_sni_bindings(elbv2, target.get("arn", ""), sni_bindings)
                try:
                    iam.delete_server_certificate(ServerCertificateName=server_certificate_name)
                    return True, f"已先移除 {removed_sni} 个 SNI 绑定，并删除 IAM 证书：{server_certificate_name}"
                except ClientError as retry_error:
                    retry_msg = retry_error.response.get("Error", {}).get("Message", str(retry_error))
                    msg = retry_msg

            if default_bindings:
                locations = "，".join(
                    f"{item.get('lb_name', '')}:{item.get('port')}"
                    for item in default_bindings
                )
                return False, f"删除失败：证书仍被以下监听器作为默认证书使用：{locations}"

        return False, f"删除失败：{msg}"
    except Exception as e:
        return False, f"删除失败：{str(e)}"

def upload_iam_cert(cert_dir, expire_date):
    """上传本地证书到 IAM，名称按 域名+到期日 生成。"""
    print('--------------开始上传证书至IAM----------------------')

    cert_domain = os.path.basename(os.path.normpath(cert_dir)).strip()
    if not cert_domain:
        raise ValueError("无法从证书目录解析域名")
    if not expire_date:
        raise ValueError("缺少证书到期时间")

    cert_name = f"{cert_domain}.{expire_date}".replace("*", "wildcard")

    def _read(*names):
        for name in names:
            path = os.path.join(cert_dir, name)
            if os.path.isfile(path):
                with open(path, 'r', encoding='utf-8') as f:
                    return f.read()
        raise FileNotFoundError(f"证书文件未找到，已尝试: {names}")

    public_key = _read('certificate.crt', 'cert.pem')
    private_key = _read('private.pem', 'privkey.pem')
    chain_key = _read('chain.crt', 'fullchain.crt', 'fullchain.pem')

    session = get_session()
    iam = session.client("iam")
    resp = iam.upload_server_certificate(
        Path='/cloudfront/',
        ServerCertificateName=cert_name,
        CertificateBody=public_key,
        PrivateKey=private_key,
        CertificateChain=chain_key
    )
    ServerCertificateId = resp['ServerCertificateMetadata']['ServerCertificateId']
    CertificateArn = resp['ServerCertificateMetadata']['Arn']
    return ServerCertificateId, CertificateArn

# 部署到 CloudFront
def deploy_cf(dist_id, ServerCertificateId):
    session = get_session()
    cf = session.client("cloudfront")
    config = cf.get_distribution_config(Id=dist_id)
    etag = config["ETag"]
    cfg = config["DistributionConfig"]

    cfg["ViewerCertificate"]["IAMCertificateId"] = ServerCertificateId
    cfg["ViewerCertificate"]["Certificate"] = ServerCertificateId

    try:
        cf.update_distribution(
            Id=dist_id,
            DistributionConfig=cfg,
            IfMatch=etag
        )
        return True, "部署成功"
    except Exception as e:
        return False, str(e)
    
# 部署到 LoadBalancer
def deploy_lb(lb_arn, CertificateArn):
    session = get_session()
    elbv2 = session.client("elbv2")
    try:
        deployed = False
        updated_ports = []
        for listener in elbv2.describe_listeners(LoadBalancerArn=lb_arn)["Listeners"]:
            protocol = str(listener.get("Protocol", "")).upper()
            has_certificates = bool(listener.get("Certificates"))
            if protocol not in {"HTTPS", "TLS"} and not has_certificates:
                continue

            elbv2.modify_listener(
                ListenerArn=listener["ListenerArn"],
                Certificates=[{"CertificateArn": CertificateArn}]
            )

            # 同时加入 SNI 证书列表，便于同一监听器按域名匹配证书。
            try:
                elbv2.add_listener_certificates(
                    ListenerArn=listener["ListenerArn"],
                    Certificates=[{"CertificateArn": CertificateArn}]
                )
            except ClientError as e:
                code = e.response.get("Error", {}).get("Code", "")
                if code not in {"DuplicateCertificate", "CertificateAlreadyExists"}:
                    raise

            deployed = True
            updated_ports.append(str(listener.get("Port")))

        if not deployed:
            return False, "未找到可更新证书的 HTTPS/TLS 监听器"

        port_text = "、".join(updated_ports)
        return True, f"部署成功，已更新监听端口：{port_text}，并加入 SNI 列表"
    except Exception as e:
        return False, str(e)


# 获取 Route53 中所有 hosted zone
def get_route53_zones():
    session = get_session()
    r53 = session.client("route53")
    try:
        resp = r53.list_hosted_zones()
        return resp.get("HostedZones", [])
    except Exception as e:
        return []


# 找到域名对应的 hosted zone id
def find_zone_id(domain):
    zones = get_route53_zones()
    # 去掉通配符前缀，取根域名
    root = domain.lstrip("*.")
    # 从最长匹配优先
    best = None
    for z in zones:
        zone_name = z["Name"].rstrip(".")
        if root == zone_name or root.endswith("." + zone_name):
            if best is None or len(zone_name) > len(best[0]):
                best = (zone_name, z["Id"].split("/")[-1])
    return best[1] if best else None


# 写入 DNS TXT 记录用于 Let's Encrypt DNS-01 验证
def upsert_dns_txt(domain, record_name, txt_value):
    zone_id = find_zone_id(domain)
    if not zone_id:
        return False, f"未找到 {domain} 对应的 Route53 Zone"
    session = get_session()
    r53 = session.client("route53")
    fqdn = record_name if record_name.endswith(".") else record_name + "."
    try:
        r53.change_resource_record_sets(
            HostedZoneId=zone_id,
            ChangeBatch={
                "Changes": [{
                    "Action": "UPSERT",
                    "ResourceRecordSet": {
                        "Name": fqdn,
                        "Type": "TXT",
                        "TTL": 60,
                        "ResourceRecords": [{"Value": f'"{txt_value}"'}]
                    }
                }]
            }
        )
        return True, f"DNS TXT 记录已写入：{record_name}"
    except Exception as e:
        return False, str(e)


# 删除 DNS TXT 记录（验证完成后清理）
def delete_dns_txt(domain, record_name, txt_value):
    zone_id = find_zone_id(domain)
    if not zone_id:
        return
    session = get_session()
    r53 = session.client("route53")
    fqdn = record_name if record_name.endswith(".") else record_name + "."
    try:
        r53.change_resource_record_sets(
            HostedZoneId=zone_id,
            ChangeBatch={
                "Changes": [{
                    "Action": "DELETE",
                    "ResourceRecordSet": {
                        "Name": fqdn,
                        "Type": "TXT",
                        "TTL": 60,
                        "ResourceRecords": [{"Value": f'"{txt_value}"'}]
                    }
                }]
            }
        )
    except Exception:
        pass